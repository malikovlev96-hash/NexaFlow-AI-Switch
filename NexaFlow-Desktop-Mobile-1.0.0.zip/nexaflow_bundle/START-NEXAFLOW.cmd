@echo off
setlocal EnableExtensions
chcp 65001 >nul
mode con: cols=100 lines=38
color 0B
title NEXAFLOW AI SWITCH - PREMIUM LAUNCHER
set "ROOT=%~dp0"
:startmenu
cls
 echo.
 echo   ███╗   ██╗███████╗██╗  ██╗ █████╗ ███████╗██╗      ██████╗ ██╗    ██╗
 echo   ████╗  ██║██╔════╝╚██╗██╔╝██╔══██╗██╔════╝██║     ██╔═══██╗██║    ██║
 echo   ██╔██╗ ██║█████╗   ╚███╔╝ ███████║█████╗  ██║     ██║   ██║██║ █╗ ██║
 echo   ██║╚██╗██║██╔══╝   ██╔██╗ ██╔══██║██╔══╝  ██║     ██║   ██║██║███╗██║
 echo   ██║ ╚████║███████╗██╔╝ ██╗██║  ██║██║     ███████╗╚██████╔╝╚███╔███╔╝
 echo   ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝  ╚══╝╚══╝
 echo.
 echo                         A I   S W I T C H   P R O
 echo                    SMART ROUTING  ^|  MULTI-MODEL  ^|  CONTROL
 echo.
 echo   ╔══════════════════════════════════════════════════════════════════════════════╗
 echo   ║                         SYSTEM INITIALIZATION                               ║
 echo   ╚══════════════════════════════════════════════════════════════════════════════╝
for %%P in ("%ROOT%NexaFlow-AI-Switch-Pro-1.6.0.mcpb" "%ROOT%mobile\index.html") do if exist %%P (echo   [  OK  ] %%~nxP) else (echo   [ WARN ] Missing %%~nxP)
echo.
 echo   [1]  OPEN MOBILE / DESKTOP WEB APP
 echo   [2]  INSTALL CLAUDE DESKTOP EXTENSION (.mcpb)
 echo   [3]  OPEN MOBILE INSTALL GUIDE
 echo   [4]  RUN LOCAL FILE CHECK
 echo   [0]  EXIT
 echo.
set /p choice=   SELECT OPTION ^> 
if "%choice%"=="1" goto webapp
if "%choice%"=="2" goto install
if "%choice%"=="3" goto guide
if "%choice%"=="4" goto check
if "%choice%"=="0" exit /b 0
echo   Unknown option. & timeout /t 2 >nul & goto :startmenu
:webapp
where py >nul 2>nul
if not errorlevel 1 (
  start "NexaFlow local server" /min py -3 -m http.server 8765 --directory "%ROOT%mobile"
) else (
  where python >nul 2>nul
  if not errorlevel 1 start "NexaFlow local server" /min python -m http.server 8765 --directory "%ROOT%mobile"
)
timeout /t 2 >nul
start "" http://127.0.0.1:8765/
echo.
echo   Browser opened. Keep this folder in place while using the local app.
pause
goto :eof
:install
if exist "%ROOT%NexaFlow-AI-Switch-Pro-1.6.0.mcpb" start "" "%ROOT%NexaFlow-AI-Switch-Pro-1.6.0.mcpb"
echo.
echo   Claude Desktop should open the extension installer.
pause
goto :eof
:guide
start "" "%ROOT%mobile\INSTALL-MOBILE.txt"
pause
goto :eof
:check
echo.
if exist "%ROOT%NexaFlow-AI-Switch-Pro-1.6.0.mcpb" (echo   [OK] MCPB package found) else (echo   [FAIL] MCPB package missing)
if exist "%ROOT%mobile\index.html" (echo   [OK] Mobile app found) else (echo   [FAIL] Mobile app missing)
if exist "%ROOT%assets\icon.png" (echo   [OK] Brand icon found) else (echo   [FAIL] Icon missing)
where python >nul 2>nul && echo   [OK] Python available for local web server || echo   [INFO] Python not found; install Python 3 to launch local web app
pause
goto :eof
